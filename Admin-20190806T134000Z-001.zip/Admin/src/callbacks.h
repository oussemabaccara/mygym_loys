#include <gtk/gtk.h>


void on_button_clicked(GtkWidget       *objet_graphique,gpointer         user_data);



void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_activ_return_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_stats_return_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_deals_return_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_admin_list_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_admin_activ_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_admin_stats_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_admin_deals_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_list_add_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_list_return_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_add_return_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_add_ajouter_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkWidget       *objgr,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkWidget       *objgr,
                                        gpointer         user_data);

void
on_button15_clicked                    (GtkWidget       *objgr2,
                                        gpointer         user_data);

void
on_button18_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button19_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button16_clicked                    (GtkWidget       *objgr,
                                        gpointer         user_data);

void
on_button23_clicked                    (GtkWidget      *objger3,
                                        gpointer         user_data);

void
on_button22_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button24_clicked                    (GtkWidget       *objger2,
                                        gpointer         user_data);

void
on_button26_clicked                    (GtkWidget      *objger4,
                                        gpointer         user_data);

void
on_button27_clicked                    (GtkWidget       *objger4,
                                        gpointer         user_data);

void
on_button25_clicked                    (GtkWidget       *objger4,
                                        gpointer         user_data);

void
on_button39_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button40_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button42_clicked                    (GtkWidget       *objger7,
                                        gpointer         user_data);

void
on_button43_clicked                    (GtkWidget       *objger5,
                                        gpointer         user_data);

void
on_button44_clicked                    (GtkWidget       *objger5,
                                        gpointer         user_data);

void
on_button45_clicked                    (GtkWidget       *objger6,
                                        gpointer         user_data);

void
on_button49_clicked                    (GtkWidget       *objger8,
                                        gpointer         user_data);

void
on_button59_clicked                    (GtkWidget       *objger9,
                                        gpointer         user_data);

void
on_calendar1_day_selected_double_click (GtkCalendar     *calendar,
                                        gpointer         user_data);

void
on_button60_clicked                    (GtkWidget      *objger10,
                                        gpointer         user_data);

void
on_button66_clicked                    (GtkWidget      *objger10,
                                        gpointer         user_data);

void
on_button67_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button69_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button68_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button62_clicked                    (GtkWidget      *objger,
                                        gpointer         user_data);

void
on_button70_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button71_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button74_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button73_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button72_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button61_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button48_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button75_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button76_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button78_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button79_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button47_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button80_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button81_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button82_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button50_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button83_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button84_activate                   (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button85_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button87_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button88_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button86_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button89_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button90_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button93_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button92_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button91_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button94_clicked                    (GtkWidget       *objger,
                                        gpointer         user_data);

void
on_button95_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_activ_add_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_activ_upd_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_search_acc_enter                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_des_acct_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_EDITT_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_edit_acc_return_enter               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_add_activ_return_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_add_activ_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_edev_return_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_edit_ev_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_delev_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_deals_return_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_deals_add_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_deals_upd_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_editdeal_return_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_editdeal_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_suppdeal_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button200_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button201_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button46_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button202_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button204_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button203_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);
