int verif( char nom[], char pwd[]);
