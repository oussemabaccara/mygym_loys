#include <gtk/gtk.h>
typedef struct
{
 char type[30];
 char jour[30];
 int horH;
 char hormin[30];
 char dur[30];
}activ;

void activadd(activ a);
