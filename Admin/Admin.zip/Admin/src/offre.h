typedef struct
{ char nbre[10];
  char description[100];
  char prix[20];
}offre;

offre getoffre(char nom[]);
