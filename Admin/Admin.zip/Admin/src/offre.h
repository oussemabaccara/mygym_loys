typedef struct
{ char nbre[10];
  char description[100];
  char prix[20];
}offre;
int existof(char num[]);
offre getoffre(char nom[]);
