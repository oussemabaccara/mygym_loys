int verifier( char nom[], char pwd[]);
