#include <gtk/gtk.h>


void on_button_clicked(GtkWidget       *objet_graphique,gpointer         user_data);



void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_activ_return_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_stats_return_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_deals_return_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_admin_list_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_admin_activ_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_admin_stats_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_admin_deals_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_list_add_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_list_return_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_add_return_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_add_ajouter_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);
