#include <gtk/gtk.h>


void on_button_clicked(GtkWidget       *objet_graphique,gpointer         user_data);

void on_button1_clicked(GtkWidget       *objet_graphique,gpointer         user_data);

void on_button5_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_clist1_select_row                   (GtkCList        *clist,
                                        gint             row,
                                        gint             column,
                                        GdkEvent        *event,
                                        gpointer         user_data);

gboolean
on_clist1_button_press_event           (GtkWidget       *widget,
                                        GdkEventButton  *event,
                                        gpointer         user_data);
void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void on_button6_clicked(GtkWidget       *objet_graphique,gpointer         user_data);

void on_button8_clicked(GtkWidget       *objet_graphique,gpointer         user_data);

void on_button7_clicked(GtkWidget       *objet_graphique,gpointer         user_data);

void on_button9_clicked(GtkWidget       *objet_graphique,gpointer         user_data);

void on_button10_clicked(GtkWidget       *objet_graphique,gpointer         user_data);

void on_button11_clicked(GtkWidget       *objet_graphique,gpointer         user_data);




